package com.flutterflow.whatsappui

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
